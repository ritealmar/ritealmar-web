# Tracking, UTMs y Analytics

## ¿Qué son los UTM?
Son fragmentos de texto que se añaden al final de un enlace (URL) para decirle a Google Analytics exactamente de dónde viene la persona que ha hecho clic.

## Para qué sirven
Sirven para saber qué correo, post o campaña ha funcionado mejor. Si RITEALMAR envía 50 emails a clínicas, queremos saber si las visitas a la web vienen de esos emails.

## Cómo crear enlaces por empresa
Estructura recomendada para enviar enlaces a clientes potenciales:
`https://ritealmar.es/auditoria-ia-gratis?utm_source=email&utm_medium=email&utm_campaign=SECTOR_TANDA&utm_content=CODIGO_EMPRESA`

**Significado:**
- `utm_source`: Fuente (ej. email, linkedin).
- `utm_medium`: Medio (ej. email, cpc, social).
- `utm_campaign`: Nombre de la campaña (ej. clinicas_tanda1).
- `utm_content`: Código único de la empresa para saber quién hizo clic.

**Ejemplos de códigos (utm_content):**
- `clin_v3_001` (Clínica, versión 3 del mail, empresa 1)
- `inmo_v4_001` (Inmobiliaria, versión 4 del mail, empresa 1)

## Cómo cruzarlo con Google Sheets
En el CRM (Google Sheets), cada empresa tiene su código (`CODIGO_EMPRESA`). Cuando RITEALMAR envía el email, envía el enlace con el UTM específico generado para esa fila.

## Cómo revisar en Analytics
1. Entrar en Google Analytics 4.
2. Ir a **Adquisición de tráfico** o **Adquisición de usuarios**.
3. Cambiar la dimensión principal a **Campaña de la sesión** o **Fuente/Medio de la sesión**.
4. Se pueden añadir dimensiones secundarias como **Contenido del anuncio de la sesión** (que corresponde a `utm_content`) para ver exactamente qué código hizo clic.

## Cómo marcar "Clic detectado: Sí"
Cuando en Analytics vemos que ha entrado una visita con el código `clin_v3_001`, vamos a nuestro Excel, buscamos la fila de esa empresa y marcamos la columna "Clic detectado" como "Sí". Esto indica que la empresa ha mostrado interés y ha visitado la web, aunque aún no haya reservado la auditoría.

## Limitaciones técnicas importantes
**Qué NO se puede saber con Gmail normal:**
- No se puede saber si el cliente abrió el correo.
- No se puede saber si lo leyó completo.
- No se puede saber si lo borró.
- *Solo podemos saber si hizo clic en el enlace usando los UTMs.* (A menos que se use un software de email marketing profesional, pero los UTM son la base).
