# Prompts de Imágenes RITEALMAR (Estilo Dark Neon)

Usa estos prompts en Gemini o en herramientas de generación de imágenes por IA para mantener la coherencia visual de la marca.

## Reglas Generales para todos los Prompts:
"Genera una imagen con estilo 'Dark Neon' tecnológico y corporativo. Los colores predominantes deben ser fondo azul marino muy oscuro o negro profundo (#050816), con acentos luminosos en cian eléctrico (#00E5FF) y magenta neón (#FF2BD6). La imagen no debe estar sobresaturada. El ambiente debe ser profesional, moderno y limpio, enfocado en tecnología B2B (dashboards, código, automatización, IA). NO incluyas textos ilegibles o palabras inventadas."

## 1. Post Cuadrado (Instagram/LinkedIn) - Concepto: Ahorro de tiempo
**Prompt:**
> Genera una imagen cuadrada (1:1). Estilo Dark Neon tecnológico. Fondo oscuro elegante. En el centro, un reloj de arena moderno y brillante donde la arena que cae se transforma en datos digitales o código luminoso color cian. Alrededor, sutiles interfaces flotantes de software o gráficas en tonos magenta. Ambiente profesional, limpio y B2B.

## 2. Reel Vertical (Portada) - Concepto: WhatsApp Automatizado
**Prompt:**
> Genera una imagen vertical (9:16) para portada de reel. Estilo Dark Neon. Un smartphone moderno flotando en un ángulo dinámico sobre un fondo oscuro, con la pantalla mostrando burbujas de chat verdes y cian muy luminosas saliendo hacia el espectador. De fondo, ligeros nodos de conexión de red brillantes. Estética profesional de automatización de negocios.

## 3. Banner LinkedIn - Concepto: Conexión de Sistemas
**Prompt:**
> Genera un banner horizontal panorámico. Estilo Dark Neon corporativo. Múltiples logotipos abstractos de aplicaciones conectados por líneas de luz brillante cian y magenta que convergen en un cerebro digital o un engranaje central brillante. Fondo azul muy oscuro. Espacio negativo a la izquierda para añadir texto posteriormente.

## 4. Imagen Google Business - Concepto: Auditoría IA
**Prompt:**
> Genera una imagen horizontal (16:9). Un escritorio de oficina oscuro y moderno, visto desde arriba o en perspectiva. Sobre la mesa, un portátil elegante con gráficos analíticos brillantes en la pantalla y una taza de café negro. Iluminación de neón sutil en el borde de la mesa (azul tecnológico). El concepto es consultoría tecnológica y auditoría para empresas. Todo muy corporativo.

## 5. Imagen para Clínicas - Concepto: Reservas
**Prompt:**
> Genera una imagen cuadrada (1:1). Estilo Dark Neon. Una interfaz abstracta y futurista de un calendario o agenda médica médica flotando en el aire. Celdas iluminadas con marcas de verificación en cian eléctrico, representando citas confirmadas automáticamente. Fondo azul muy oscuro. Sin texto escrito.

## 6. Imagen para Inmobiliarias - Concepto: CRM y Leads
**Prompt:**
> Genera una imagen cuadrada (1:1). Estilo Dark Neon. Un embudo de ventas digital brillante y holográfico flotando sobre una mesa oscura. Pequeños iconos luminosos con forma de casas y avatares de personas fluyen organizadamente hacia la parte inferior del embudo y se conectan a un dashboard. Colores cian y magenta.

## Instrucciones adicionales para el Gem:
Si tienes que sugerir un texto para sobreimpresionar en estas imágenes, recuerda que **RITEALMAR** debe escribirse siempre en mayúsculas y usar una fuente tipográfica moderna y sin remates (sans-serif) como Inter, Montserrat o Roboto.
