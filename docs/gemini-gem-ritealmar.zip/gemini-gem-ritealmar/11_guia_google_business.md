# Guía de Google Business para RITEALMAR

## Qué Publicar en Google Business
- **Novedades y Actualizaciones:** Nuevos servicios, mejoras en la plataforma o noticias de la empresa.
- **Ofertas y Promociones:** Destacar la Auditoría IA Gratuita.
- **Educación:** Breves tips sobre cómo la IA ayuda a las PYMEs.
- **Fotos de Equipo/Oficina:** Imágenes que muestren el lado humano (si aplica) o setups tecnológicos corporativos (Dark Neon).

## Frecuencia Recomendada
- 1 publicación semanal. Google prioriza fichas que se mantienen activas.

## Tipos de Publicaciones
- **Tipo "Oferta":** Para la auditoría IA gratuita (añadir fechas de inicio y fin).
- **Tipo "Novedad":** Para posts informativos o tips de automatización.
- **Tipo "Evento":** Si RITEALMAR hace un webinar o charla (poco frecuente).

## Textos de Ejemplo
- "¿Tu clínica pierde citas porque los pacientes se olvidan? Automatizamos tus recordatorios por WhatsApp para que no pierdas dinero. Pide tu auditoría gratuita y te explicamos cómo."

## CTAs Recomendados (Botones de Google)
- **"Más información"**: Enlaza a la página del servicio o a la home.
- **"Reservar" / "Registrarse"**: Enlaza a Calendly o a la página de Auditoría.
- **"Llamar ahora"**: Botón directo (hacia el teléfono o WhatsApp).

## Ideas de Fotos
- Gráficos limpios, dashboards, el logo de RITEALMAR iluminado, personas trabajando con portátiles. Estilo profesional y Dark Neon.

## Cómo Pedir Reseñas Reales
- Solicitar una reseña **solo** a clientes reales que hayan quedado satisfechos con un servicio de automatización, web o CRM.
- **Enlace directo a compartir:** `https://g.page/r/CRTqo5MvkinrEBM/review`
- **Mensaje para pedir reseña:** "Hola [Nombre], nos alegra mucho que el nuevo sistema esté funcionando tan bien en tu negocio. Si tienes 1 minuto, nos ayudaría muchísimo que dejaras una breve reseña en Google sobre tu experiencia trabajando con RITEALMAR. Aquí tienes el enlace directo: [Enlace]. ¡Mil gracias!"

## Qué Evitar
- No comprar reseñas falsas.
- No inventar clientes.
- No subir fotos pixeladas o con demasiada información/texto.
