# Preguntas Frecuentes de Clientes (FAQ)

## ¿Qué es una automatización?
Es conectar dos o más herramientas digitales para que trabajen solas. Por ejemplo, que cuando un cliente rellene un formulario en tu web, se guarde automáticamente en tu Excel de clientes y se le envíe un WhatsApp de bienvenida, sin que tú toques nada.

## ¿Qué es un agente de IA?
Es un programa inteligente que puede conversar con tus clientes como si fuera un humano, respondiendo dudas sobre horarios, precios o servicios basándose en la información de tu negocio.

## ¿Necesito cambiar mi CRM o mi forma de trabajar?
No. En la mayoría de los casos, RITEALMAR conecta tus herramientas actuales (como tu Google Calendar o tu CRM de siempre) con nuevas funcionalidades, sin que tengas que cambiar todo tu sistema.

## ¿Puedo automatizar WhatsApp?
Sí. Podemos configurar respuestas automáticas complejas, envío de recordatorios de citas, confirmaciones de pedido y filtrado de clientes directamente en WhatsApp Business.

## ¿Sirve para clínicas?
Por supuesto. Es uno de nuestros sectores principales. Automatizamos confirmaciones de citas, seguimiento de pacientes y dudas frecuentes para liberar a recepción.

## ¿Sirve para inmobiliarias?
Sí. Conectamos los portales (Idealista, Fotocasa) con tu WhatsApp y CRM para responder en segundos a cualquier interesado en un inmueble.

## ¿Cuánto tarda una automatización en estar lista?
Depende de la complejidad. Automatizaciones simples (como conectar un formulario a un Excel) pueden estar en días. Desarrollos a medida o chatbots complejos pueden llevar un par de semanas. Lo revisamos en la auditoría.

## ¿La auditoría es gratuita?
Sí, la revisión inicial de 15-30 minutos para detectar cuellos de botella y oportunidades es totalmente gratuita y sin compromiso.

## ¿Qué se revisa en la auditoría?
Revisamos cómo captas clientes, cómo los atiendes, dónde pierdes tiempo copiando datos y qué procesos manuales podríamos eliminar con tecnología.

## ¿Qué pasa después de la auditoría?
Te damos nuestra valoración. Si vemos que podemos ayudarte, te enviamos una propuesta comercial adaptada. Si no te interesa, te llevas el diagnóstico gratis.

## ¿Trabajáis con empresas pequeñas?
Especialmente con empresas pequeñas. Sabemos que sois los que menos tiempo tenéis y los que más necesitáis la tecnología para crecer sin contratar a decenas de personas.

## ¿Esto sustituye a mis empleados?
No. Las automatizaciones quitan el trabajo robótico y aburrido (copiar datos, responder "¿a qué hora abrís?"). Tus empleados podrán centrarse en vender, dar mejor servicio y aportar valor real.

## ¿Podéis mejorar mi web?
Sí, ofrecemos desarrollo web orientado a la captación de clientes. No hacemos webs solo "bonitas", hacemos webs que funcionan como comerciales 24/7.

## ¿Podéis conectar formularios con nuestro CRM?
Sí. Hacemos que cualquier dato introducido en tu web viaje de forma segura y automática al sistema que uses para gestionar clientes.

## ¿Cómo se mide si funciona?
Lo mides en horas ahorradas a la semana (que antes gastabas en tareas manuales) y en el aumento de clientes atendidos o citas no perdidas gracias a la rapidez de respuesta.
