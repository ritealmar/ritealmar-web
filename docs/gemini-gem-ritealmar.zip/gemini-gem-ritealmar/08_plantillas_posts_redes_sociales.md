# Plantillas para Posts en Redes Sociales

## 1. LinkedIn (B2B - Profesional)
- **Estructura:**
  1. Gancho fuerte (1 línea, rompe el scroll).
  2. El problema (desarrollo breve, empatía).
  3. La solución real (cómo se resuelve sin ser excesivamente técnico).
  4. La invitación (CTA a la auditoría gratuita).
- **Ejemplo:**
  Si tardas más de 5 minutos en responder a un nuevo contacto de la web, es probable que ya esté hablando con tu competencia.

  Muchas PYMEs gastan dinero en captar visitas, pero los formularios llegan a un correo genérico que se revisa dos veces al día.

  En RITEALMAR conectamos tu web directamente con tu CRM y configuramos un aviso inmediato a tu comercial. El cliente recibe un WhatsApp de confirmación en el acto.

  ¿Te pasa esto? Revisa qué procesos podrías automatizar primero.
  👇 Solicita tu Auditoría IA Gratuita aquí:
  [Enlace]
- **Hashtags:** `#Automatizacion #PYMEs #Productividad #RITEALMAR`
- **Idea visual:** Gráfico que muestre la curva de caída de interés de un lead según los minutos de espera.

## 2. Instagram / Facebook (Visual y Cercano)
- **Estructura:**
  1. Título visual en la imagen.
  2. Gancho en el texto.
  3. Puntos clave (viñetas).
  4. CTA claro al enlace de la bio.
- **Ejemplo:**
  Imagen: "3 tareas que un robot debería hacer por ti" (Estilo Dark Neon).
  Texto:
  ¿Sigues copiando datos de un Excel a otro? 🤖❌

  Tu tiempo (y el de tu equipo) vale demasiado para hacer tareas repetitivas. Esto es lo que deberías automatizar hoy:
  ✅ Envío de presupuestos estándar.
  ✅ Recordatorios de citas por WhatsApp.
  ✅ Volcado de datos de formularios a tu base de datos.

  En RITEALMAR te ayudamos a hacerlo sin complicaciones.
  👉 Solicita tu auditoría IA gratuita en el enlace de nuestro perfil.
- **Hashtags:** `#InteligenciaArtificial #NegociosLocales #RITEALMAR #Automatizar`
- **Idea visual:** Carrusel 1:1, colores azul marino y cian, texto grande y legible.

## 3. TikTok / Reels (Dinámico y Rápido)
- **Estructura:**
  1. Gancho verbal (primeros 3 segundos).
  2. Explicación del problema actuando o mostrando pantalla.
  3. Solución rápida de RITEALMAR.
  4. CTA verbal ("Link en bio").
- **Ejemplo:**
  (Gancho): "¿Tus clientes de la clínica se olvidan de la cita y pierdes dinero?"
  (Problema): "Tener a alguien llamando uno por uno es súper ineficiente."
  (Solución): "Con una simple automatización, tu calendario envía un WhatsApp automático 24h antes para que confirmen o cancelen con un botón."
  (CTA): "Si quieres esto para tu negocio, pide una auditoría gratis en RITEALMAR. Link en bio."
- **Hashtags:** `#Clinicas #TipsNegocios #AutomatizacionWhatsApp #RITEALMAR`
- **Idea visual:** Vertical 9:16, dinámico, subtítulos grandes en magenta/cian.

## 4. Google Business (Local y Directo)
- **Estructura:**
  1. Titular directo (Qué ofrecemos).
  2. Descripción breve (Beneficio).
  3. CTA con botón integrado de Google.
- **Ejemplo:**
  ¿Tu negocio pierde clientes por no poder responder a tiempo?
  Con los servicios de RITEALMAR Sistemas IA, instalamos chatbots y automatizamos tu WhatsApp para que atiendas 24/7 sin esfuerzo. Ahorra tiempo y capta más ventas.
  Pide hoy tu Auditoría IA Gratuita y revisemos tu caso sin compromiso.
- **CTA:** Botón "Más información" hacia la web de auditoría.
- **Idea visual:** Imagen horizontal corporativa, logo RITEALMAR bien visible, fondo oscuro.
