# Guía de Estilo y Copywriting

## Cómo escribir Hooks (Ganchos)
El objetivo de las dos primeras líneas es que el lector no haga scroll.
- **Hablar del problema:** "¿Tu comercial pierde 2 horas al día copiando datos?"
- **Hacer una pregunta directa:** "Si tardas más de 5 minutos en responder a la web, ¿sabes qué hace tu cliente?"
- **Cuestionar una creencia:** "Tener un Excel no es tener un CRM."

## Cómo estructurar un post/texto
1. **Hook:** Captar la atención.
2. **Empatía/Problema:** Demostrar que entendemos lo que sufren.
3. **Transición:** Introducir la posibilidad de mejora.
4. **Solución:** Explicar cómo RITEALMAR lo arregla de forma sencilla.
5. **CTA:** Llamada a la acción clara.

## Cómo escribir CTA (Llamadas a la acción)
Deben ser concretos y decir exactamente qué va a pasar.
- **Sí:** "Solicita tu auditoría IA gratuita aquí" / "Revisa qué procesos podrías automatizar".
- **No:** "Contáctanos" / "Haz clic aquí" / "Compra ya".

## Cómo usar Emojis
Con moderación para estructurar el texto, no para adornar sin sentido.
- **Recomendados:** ⏱️, 🚀, 🤖, 📉, ✅, ❌, 👇, 👉.
- **Evitar:** Caras llorando de risa en exceso, demasiados colores que rompan el estilo serio pero cercano.

## Cómo usar Hashtags
Al final del texto, separados por un salto de línea. Nunca en medio de una frase.
- Máximo 3-5 hashtags relevantes.

## Frases Recomendadas
- "Detecta tareas repetitivas que consumen tiempo."
- "Revisa qué procesos podrías automatizar primero."
- "Empieza con una revisión inicial sin compromiso."
- "Ayudamos a PYMEs a modernizarse sin complicarse con la tecnología."

## Frases Prohibidas
- "Gana miles de euros con Inteligencia Artificial." (Humo)
- "Te garantizamos multiplicar tus ventas." (Falso, no prometemos resultados)
- "Somos la mejor empresa del mundo." (Ego)
- Uso excesivo de palabras como "Revolucionario", "Mágico", "Increíble".

## Ejemplos Buenos y Malos
- **MAL:** "Instalamos API REST en tu webhook para conectar el frontend con el backend y hacer un parsing del payload." (Demasiado técnico).
- **BIEN:** "Conectamos tu formulario web con tu Excel para que los datos aparezcan solos al instante." (Claro y orientado al beneficio).

## Cómo evitar sonar a Spam (Especial para Emails)
- No usar mayúsculas en los asuntos ("¡¡¡GANA MAS CLIENTES!!!").
- Ser breve (nadie lee emails largos de desconocidos).
- Aportar valor en el primer párrafo (ej. "He revisado tu web").

## Adaptación por Canal
- **LinkedIn:** Profesional, enfoque en eficiencia, ahorro de costes y gestión de equipos.
- **Instagram/Facebook:** Visual, beneficios directos, historias de negocios locales, tono más relajado.
- **Google Business:** Directo al grano, transaccional, enfocado en servicios locales.
