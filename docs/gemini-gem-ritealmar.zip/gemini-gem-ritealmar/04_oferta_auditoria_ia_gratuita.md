# Oferta: Auditoría IA Gratuita

## ¿Qué es la auditoría IA gratuita?
Es una revisión inicial sin coste y sin compromiso para ayudar a las empresas a identificar qué áreas de su negocio están consumiendo tiempo de forma innecesaria y cómo la Inteligencia Artificial o la automatización pueden solucionarlo.

## ¿Qué analiza?
- Recepción de mensajes y canales de atención.
- Procesos de reserva, citas o presupuestos.
- Tareas repetitivas administrativas o de ventas.
- Presencia online y sistema de captación actual.

## ¿Qué puede recibir el cliente?
- Una videollamada de 30 minutos (Calendly).
- Un diagnóstico rápido de cuellos de botella.
- Sugerencias prácticas de herramientas o procesos a mejorar.

## ¿Qué NO promete?
- No promete resultados garantizados (ventas, x clientes nuevos).
- No es una consultoría técnica profunda o un desarrollo gratis.

## Cómo comunicarla en redes
- Como un beneficio exclusivo y de alto valor, pero de fácil acceso.
- Resaltando el ahorro de tiempo y el descubrimiento de oportunidades.

## Cómo comunicarla por email
- Tono directo, ofreciendo ayuda y centrándose en el problema del sector.
- "He visto tu web y creo que podríamos ayudarte a automatizar X. ¿Hablamos 15 min?"

## CTAs recomendados
- "Solicita tu auditoría IA gratuita"
- "Agenda tu revisión gratuita"
- "Descubre qué automatizar en tu negocio (Gratis)"

## Frases para no sonar agresivo
- "Si te encaja, genial. Si no, al menos te llevas una revisión de tu sistema."
- "Es una charla de 15 minutos, sin compromiso de contratación."

## Frases para captar clientes
- "Revisa qué procesos podrías automatizar primero."
- "Detecta tareas repetitivas que consumen tiempo."
- "Empieza con una revisión inicial sin compromiso."
