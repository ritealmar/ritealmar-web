# Glosario RITEALMAR para Clientes

Términos explicados de forma sencilla para usar en comunicaciones:

- **IA (Inteligencia Artificial):** Programas informáticos diseñados para hacer tareas que normalmente requerirían inteligencia humana, como entender texto, responder preguntas o analizar datos.
- **Automatización:** Conectar diferentes programas para que las tareas repetitivas se hagan solas sin que una persona tenga que intervenir.
- **CRM (Customer Relationship Management):** Un sistema (software) para organizar y gestionar la información de todos tus clientes, las ventas en curso y el seguimiento comercial. Mucho mejor que un Excel.
- **Lead:** Una persona que ha mostrado interés en tu servicio dejando sus datos de contacto (email, teléfono). Un cliente potencial.
- **Chatbot:** Un programa que responde automáticamente mensajes en una web o red social siguiendo unas reglas predefinidas.
- **Agente de IA:** Un chatbot avanzado que no solo sigue reglas, sino que entiende el contexto gracias a la IA y puede tener conversaciones naturales.
- **Formulario Conectado:** Un cuestionario online que, al ser rellenado, envía automáticamente los datos a tu correo, a tu Excel o a tu CRM.
- **UTM:** Pequeños códigos invisibles que se añaden a un enlace web para saber exactamente de dónde viene un visitante (ej. desde un email o un anuncio).
- **Conversión:** Cuando un visitante de tu web realiza la acción que tú querías (ej. rellenar el formulario de auditoría).
- **Auditoría IA:** Nuestra revisión gratuita de 15-30 minutos para analizar los procesos de un negocio y ver qué se puede mejorar.
- **Google Business (Perfil de Empresa):** La ficha de tu negocio que aparece en Google Maps y en el buscador cuando alguien te busca.
- **SEO Local:** Acciones para que tu negocio aparezca el primero en Google cuando alguien busca tus servicios en tu ciudad.
- **Embudo de Ventas:** El camino por el que pasa una persona desde que no te conoce de nada hasta que se convierte en cliente.
- **Seguimiento Comercial (Follow-up):** Las acciones (llamadas, emails, WhatsApp) que haces para mantener el contacto con un lead hasta que compra.
