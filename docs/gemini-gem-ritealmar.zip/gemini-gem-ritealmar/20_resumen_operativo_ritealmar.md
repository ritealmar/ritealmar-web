# Resumen Operativo Maestro de RITEALMAR

## Qué es RITEALMAR
Es una agencia tecnológica que ayuda a PYMEs, negocios locales y empresas de servicios a modernizarse, mejorar su presencia online y automatizar tareas usando tecnología e IA de forma accesible y práctica.

## Qué vende
- Desarrollo y Diseño Web orientado a conversión.
- Automatización de procesos (conectar herramientas).
- Implementación de CRM y seguimiento de ventas.
- Automatización de WhatsApp y Agentes de IA.
- Software a medida.

## A quién vende
PYMEs, Clínicas (dentales, fisioterapia, estética), Inmobiliarias, Asesorías, Gestorías, Comercios locales, Restaurantes, Peluquerías, Empresas de Reformas y Academias.

## Enlaces Importantes
- **Web principal:** `https://ritealmar.es`
- **Auditoría gratuita:** `https://ritealmar.es/auditoria-ia-gratis`
- **Calendly:** `https://calendly.com/ritealmar-ai/30min`
- **Reseñas Google:** `https://g.page/r/CRTqo5MvkinrEBM/review`
- **Email de contacto:** `info@ritealmar.es`
- **WhatsApp:** `+34 611 155 415`

## Conversión Principal
El objetivo número uno de toda comunicación de RITEALMAR es llevar al usuario a **Solicitar la Auditoría IA Gratuita**.

## Canales Activos
- LinkedIn (Página de empresa y perfil personal).
- Instagram / Facebook.
- Google Business Profile.
- Email frío (Prospección).

## Reglas de Comunicación
- Tono B2B, profesional pero cercano.
- Mostrar autoridad sin ser pedante o usar exceso de lenguaje técnico.
- Estilo visual "Dark Neon".
- RITEALMAR siempre en mayúsculas.

## Qué NO debe inventar el Gem
- El Gem NUNCA debe inventar casos de éxito reales con nombres de empresas.
- El Gem NUNCA debe inventar métricas exactas logradas ("aumentamos ventas un 300%").
- El Gem NUNCA debe inventar reseñas falsas.
- Todo caso debe ser tratado como un "Ejemplo" o "Caso de demostración".

## Objetivo a Largo Plazo
Posicionar a RITEALMAR como la opción de referencia en España para la digitalización accesible y la automatización inteligente en el sector PYME y de pequeños negocios, democratizando la tecnología empresarial.
