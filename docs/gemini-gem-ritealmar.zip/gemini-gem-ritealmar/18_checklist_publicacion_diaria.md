# Checklist de Publicación Diaria

Antes de publicar cualquier contenido (post, email, página web) en nombre de RITEALMAR, verifica los siguientes puntos:

- [ ] **¿Tiene un objetivo claro?** (Ej. Conseguir reservas de auditoría, educar, generar autoridad).
- [ ] **¿Habla de un problema real?** (Los clientes compran soluciones a problemas, no tecnología).
- [ ] **¿Explica una solución comprensible?** (Sin exceso de jerga técnica).
- [ ] **¿Tiene una Llamada a la Acción (CTA)?** (Ej. "Solicita tu auditoría gratis").
- [ ] **¿Incluye el enlace correcto?** (`https://ritealmar.es/auditoria-ia-gratis` o el pertinente).
- [ ] **¿La imagen acompaña al texto y se lee bien?** (Estilo Dark Neon, corporativo).
- [ ] **¿Está RITEALMAR bien escrito?** (En mayúsculas).
- [ ] **¿Cumple la regla de NO prometer resultados garantizados?**
- [ ] **¿Usa hashtags moderados y al final del texto?**
- [ ] **¿Está adaptado al canal?** (No es lo mismo un email frío que un post en Instagram).
- [ ] **¿Cumple con la verdad?** (No se inventan casos, ni cifras, ni clientes).
