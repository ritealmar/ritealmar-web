# Calendario Editorial RITEALMAR (30 Días)

**Prioridad:**
- 2-3 posts/semana para LinkedIn (B2B).
- 2-3 posts/semana para Instagram/Facebook.
- 1 post/semana para Google Business.
- 1-2 Reels/semana.

## Semana 1
- **Día 1 (LinkedIn):** Tema: Por qué responder en 5 minutos cambia todo. Gancho: "Si tardas más de 5 minutos, tu competencia ya ha contestado." CTA: Auditoría IA.
- **Día 2 (Instagram/FB - Post):** Tema: Qué es automatizar. Gancho: "Si copias y pegas datos, eres un robot." CTA: Auditoría IA. Idea visual: Dark neon, persona frustrada vs dashboard.
- **Día 3 (Reel/TikTok):** Tema: Formularios al email sin respuesta. Gancho: "¿Tus formularios web llegan a un email que nadie mira?" CTA: Auditoría IA.
- **Día 4 (Google Business):** Tema: Presentación auditoría. Gancho: "Revisamos tus procesos gratis." CTA: Enlace a web.
- **Día 5 (LinkedIn):** Tema: Objeción CRM. Gancho: "Tener un CRM no sirve de nada si tienes que meter los datos a mano." CTA: Auditoría IA.

## Semana 2
- **Día 8 (LinkedIn):** Tema: Automatización en Clínicas. Gancho: "El 20% de las citas médicas se pierden. Así lo evitamos." CTA: Auditoría IA.
- **Día 9 (Instagram/FB - Carrusel):** Tema: 3 tareas que debes dejar de hacer a mano hoy. Gancho: "Estás perdiendo 10 horas a la semana." CTA: Auditoría IA.
- **Día 10 (Reel/TikTok):** Tema: Dudas en redes a las 11 PM. Gancho: "¿Quién atiende tu negocio cuando tú duermes?" CTA: Auditoría IA.
- **Día 11 (Google Business):** Tema: Reseñas automatizadas. Gancho: "Conseguimos reseñas reales automáticamente." CTA: Enlace a web.
- **Día 12 (LinkedIn):** Tema: Inmobiliarias. Gancho: "Un lead de Idealista tiene una vida útil de minutos." CTA: Auditoría IA.

## Semana 3
- **Día 15 (LinkedIn):** Tema: Qué es la Auditoría IA. Gancho: "¿Miedo a la IA? Empecemos por lo básico (y gratis)." CTA: Auditoría IA.
- **Día 16 (Instagram/FB - Post):** Tema: IA para PYMEs. Gancho: "La IA no es solo para multinacionales." CTA: Auditoría IA. Idea visual: Móvil con logo RITEALMAR.
- **Día 17 (Reel/TikTok):** Tema: Cómo automatizamos un proceso. Gancho: "Mira cómo un Excel se rellena solo (Demo rápida)." CTA: Auditoría IA.
- **Día 18 (Google Business):** Tema: Software a medida. Gancho: "¿Tu programa no hace lo que necesitas? Lo creamos." CTA: Enlace a web.
- **Día 19 (LinkedIn):** Tema: Asesorías. Gancho: "El drama de pedir los trimestres a tus clientes." CTA: Auditoría IA.

## Semana 4
- **Día 22 (LinkedIn):** Tema: Formularios conectados. Gancho: "El viaje del dato: de la web al comercial en 1 segundo." CTA: Auditoría IA.
- **Día 23 (Instagram/FB - Carrusel):** Tema: Mitos de la IA en negocios. Gancho: "3 mentiras que te han contado sobre automatizar." CTA: Auditoría IA.
- **Día 24 (Reel/TikTok):** Tema: Reservas de restaurantes. Gancho: "Atiende la sala, nosotros el WhatsApp." CTA: Auditoría IA.
- **Día 25 (Google Business):** Tema: Actualización de servicios. Gancho: "Automatizamos tu atención al cliente." CTA: Enlace a web.
- **Día 26 (LinkedIn):** Tema: Valor real. Gancho: "No vendemos bots. Vendemos tiempo." CTA: Auditoría IA.

## Semana 5 (Cierre de mes)
- **Día 29 (LinkedIn):** Tema: Resumen del mes / Caso hipotético. Gancho: "Cómo ahorrar 40h al mes en administración." CTA: Auditoría IA.
- **Día 30 (Instagram/FB):** Tema: Promoción directa Auditoría. Gancho: "Últimas plazas para auditorías gratuitas este mes." CTA: Auditoría IA.
