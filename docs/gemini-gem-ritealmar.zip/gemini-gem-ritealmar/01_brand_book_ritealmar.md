# Brand Book y Guía de Marca de RITEALMAR

## Identidad de Marca
- **Nombre comercial:** RITEALMAR
- **Nombre habitual en redes:** RITEALMAR Sistemas IA

## Misión
Ayudar a PYMEs y negocios locales a captar más clientes, mejorar su presencia online y automatizar procesos mediante inteligencia artificial y sistemas digitales de forma accesible.

## Visión
Convertirnos en el socio tecnológico de confianza para empresas que quieren modernizarse sin complicarse con jerga técnica o herramientas innecesarias.

## Valores
- Transparencia.
- Orientación a resultados prácticos.
- Cercanía.
- Innovación accesible.
- Profesionalidad.

## Tono de Voz
Profesional, cercano, claro, directo, práctico, comercial sin ser agresivo y orientado a resultados.
**Reglas:**
- Sin prometer resultados garantizados.
- Sin lenguaje técnico innecesario (evitar sonar a humo tecnológico).

## Palabras y Expresiones
### Recomendadas
- "Automatizar procesos", "Ahorrar tiempo", "Captar oportunidades", "Eficiencia", "Solución a medida", "Presencia online", "Seguimiento comercial".

### A Evitar
- "Hacerse rico rápido", "Ventas garantizadas", "El mejor del mundo", "Revolucionario", jerga excesivamente técnica sin explicar.

## Estilo Visual
- **Temática:** Dark Neon, tecnológico, corporativo.
- **Elementos comunes:** Uso de dashboards, CRM, WhatsApp, formularios, IA, automatización, portátiles, móviles e interfaces digitales.

### Paleta de Colores
- **Negro profundo:** `#050816`
- **Azul marino oscuro:** `#071426`
- **Cian eléctrico:** `#00E5FF`
- **Azul tecnológico:** `#2563EB`
- **Magenta neón:** `#FF2BD6`
- **Blanco:** `#FFFFFF`
- **Gris claro:** `#CBD5E1`
