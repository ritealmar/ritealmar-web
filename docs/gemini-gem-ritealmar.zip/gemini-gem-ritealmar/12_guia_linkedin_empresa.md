# Guía de Comunicación en LinkedIn

## Cómo debe comunicar RITEALMAR en LinkedIn
La comunicación debe ser profesional, orientada a B2B (Business to Business), pero cercana y libre de jerga técnica innecesaria. El objetivo es posicionar a RITEALMAR como el socio tecnológico ideal para PYMEs.

## Diferencia entre Perfil Personal y Página de Empresa
- **Perfil Personal (Ricardo):** Tono más personal, opiniones, experiencias, lecciones aprendidas en el día a día montando sistemas. Conecta de persona a persona.
- **Página de Empresa (RITEALMAR):** Tono corporativo, casos de uso, servicios, explicaciones estructuradas, autoridad de marca y novedades.

## Ideas de Posts
### 1. Posts Educativos (Aportar Valor)
- Cómo un CRM ahorra 10h semanales a un comercial.
- Por qué un Excel no es escalable.
- Diferencia entre un bot de WhatsApp malo (que frustra) y uno bueno (que filtra y ayuda).

### 2. Posts Comerciales Suaves
- Presentación de la Auditoría IA Gratuita.
- Explicación de cómo conectamos formularios web a la base de datos de un cliente (ejemplo).

### 3. Posts de Autoridad
- Compartir noticias sobre IA aplicadas a pequeños negocios (y dar la opinión de RITEALMAR).
- Listas de chequeo (Checklist): "5 cosas que tu web debe tener para captar leads".

## Cómo Comentar desde el Perfil Personal
- No hacer spam en posts de otros.
- Aportar valor. Si alguien pregunta por un problema técnico, dar un consejo útil sin intentar vender agresivamente en el primer comentario.

## Cómo Invitar Contactos
- Buscar dueños de PYMEs, directores de clínicas, gerentes de inmobiliarias.
- **Mensaje de invitación:** "Hola [Nombre], veo que diriges una [Tipo de empresa] en [Ciudad]. Me encantaría conectar por aquí para compartir ideas sobre optimización y tecnología en negocios locales. Un saludo."

## Hashtags Recomendados
- Usar de 3 a 5 hashtags al final.
- `#Automatizacion #PYMEs #Productividad #Tecnologia #RITEALMAR #InteligenciaArtificial`

## CTA a Auditoría Gratuita
- "Si tu negocio necesita ordenar estos procesos, solicita una Auditoría IA gratuita en el primer comentario." (LinkedIn prefiere los enlaces en los comentarios para no reducir el alcance).
