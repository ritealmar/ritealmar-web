# Sistema de Prospección B2B

## Reglas de Prospección
- **No hacer spam:** Personalizar los mensajes y contactar solo con negocios a los que RITEALMAR pueda ayudar realmente.
- **Enviar tandas pequeñas:** No enviar miles de correos masivos. Usar envíos controlados (ej. 20-30 al día) muy enfocados.

## Registrar todo en Google Sheets (CRM Básico)
Llevar un control exhaustivo en Google Sheets o en el CRM interno de RITEALMAR.
**Campos recomendados:**
- Fecha
- Empresa
- Sector
- Web
- Teléfono
- Email
- Ciudad
- Contactado (Sí/No)
- Respuesta (Sí/No)
- Notas
- Código tracking
- Campaña UTM
- Enlace enviado
- Clic detectado
- Fecha clic

## Cómo Registrar Respuestas y Rebotes
- **Respuestas:** Anotar en 'Notas' la objeción o el interés. Mover a columna 'Interesado' o 'Agenda Llamada'.
- **Rebotes (Email no existe):** Marcar en rojo y borrar de la lista de próximos envíos.

## Cómo Responder a...
- **Interesados:** "Genial, [Nombre]. Te propongo una videollamada de 15 min este [Día] a las [Hora]. Aquí tienes mi Calendly si prefieres elegir hueco: [Enlace]".
- **No interesados:** "Entendido, [Nombre]. Gracias por responder. Si en el futuro necesitáis optimizar algún proceso digital, ya tenéis mi contacto. Un saludo."

## Cómo Hacer Seguimiento
- Si no hay respuesta tras el 1er email, enviar un **único** recordatorio a los 4-5 días.
- "Hola [Nombre], solo quería asegurar que viste mi correo anterior sobre cómo automatizar [Proceso]. Si ahora no es el momento, sin problema."

## Plantillas de Email por Sector

### Clínicas (Ejemplo)
**Asunto:** ¿Cómo gestionáis las citas perdidas en [Nombre Clínica]?
**Cuerpo:**
Hola [Nombre],
He estado viendo la web de [Nombre Clínica] y me ha gustado mucho vuestro enfoque.
Trabajando con otras clínicas hemos visto que pierden muchas citas porque los pacientes olvidan confirmar. En RITEALMAR implementamos avisos por WhatsApp que reducen esto a casi cero de forma automática.
¿Os pasa esto a menudo? Si es así, ofrecemos una auditoría gratuita de 15 min para ver si os encajaría.
Un saludo.

### Inmobiliarias (Ejemplo)
**Asunto:** Contactos de Idealista para [Nombre Inmobiliaria]
**Cuerpo:**
Hola [Nombre],
He visto vuestra cartera de pisos en la web.
Muchas agencias tardan en responder los leads de portales inmobiliarios y pierden al cliente. Nosotros conectamos los portales con WhatsApp para que el cliente reciba un mensaje al instante.
¿Es un problema para vosotros la velocidad de respuesta? Si queréis, lo revisamos en una auditoría de 15 min gratis.
Un saludo.
