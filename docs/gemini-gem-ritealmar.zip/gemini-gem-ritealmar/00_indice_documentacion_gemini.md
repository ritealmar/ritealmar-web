# Índice de Documentación para Gemini (RITEALMAR)

Este directorio contiene la base documental completa de RITEALMAR para ser utilizada como conocimiento en el Gem de Gemini.

1. **[01_brand_book_ritealmar.md](./01_brand_book_ritealmar.md)**: Identidad de marca, tono, estilo visual y colores.
2. **[02_servicios_ritealmar.md](./02_servicios_ritealmar.md)**: Servicios reales, problemas que resuelve y beneficios.
3. **[03_publico_objetivo_ritealmar.md](./03_publico_objetivo_ritealmar.md)**: Cliente ideal, sectores y dolores principales.
4. **[04_oferta_auditoria_ia_gratuita.md](./04_oferta_auditoria_ia_gratuita.md)**: Detalles de la auditoría IA gratuita y cómo comunicarla.
5. **[05_mensajes_comerciales_por_sector.md](./05_mensajes_comerciales_por_sector.md)**: Mensajes, ganchos y ejemplos adaptados a cada sector.
6. **[06_objeciones_y_respuestas.md](./06_objeciones_y_respuestas.md)**: Objeciones frecuentes y cómo responder de forma profesional.
7. **[07_calendario_editorial_ritealmar.md](./07_calendario_editorial_ritealmar.md)**: Calendario de 30 días para distintas redes sociales.
8. **[08_plantillas_posts_redes_sociales.md](./08_plantillas_posts_redes_sociales.md)**: Plantillas reutilizables por canal.
9. **[09_prompts_imagenes_ritealmar.md](./09_prompts_imagenes_ritealmar.md)**: Prompts para generar imágenes con IA adaptadas a la marca.
10. **[10_keywords_seo_ritealmar.md](./10_keywords_seo_ritealmar.md)**: Palabras clave SEO y su intención de búsqueda.
11. **[11_guia_google_business.md](./11_guia_google_business.md)**: Cómo gestionar y publicar en el perfil de Google Business.
12. **[12_guia_linkedin_empresa.md](./12_guia_linkedin_empresa.md)**: Estrategia y comunicación para LinkedIn.
13. **[13_sistema_prospeccion_b2b.md](./13_sistema_prospeccion_b2b.md)**: Reglas, seguimiento y plantillas para captación.
14. **[14_tracking_utm_y_analytics.md](./14_tracking_utm_y_analytics.md)**: Uso de UTMs y métricas.
15. **[15_faq_clientes_ritealmar.md](./15_faq_clientes_ritealmar.md)**: Preguntas frecuentes de los clientes y sus respuestas.
16. **[16_casos_demo_y_ejemplos.md](./16_casos_demo_y_ejemplos.md)**: Ejemplos hipotéticos de soluciones por sector.
17. **[17_guia_de_estilo_copywriting.md](./17_guia_de_estilo_copywriting.md)**: Técnicas de copy, estructura y frases recomendadas.
18. **[18_checklist_publicacion_diaria.md](./18_checklist_publicacion_diaria.md)**: Puntos a revisar antes de cada publicación.
19. **[19_glosario_ritealmar.md](./19_glosario_ritealmar.md)**: Definiciones sencillas de términos tecnológicos.
20. **[20_resumen_operativo_ritealmar.md](./20_resumen_operativo_ritealmar.md)**: Resumen maestro de la marca y sus canales.
